
<title> Ordonner</title>
<h1>Ordre</h1>

<?php
echo validation_errors();
echo form_open();
$i=10;
foreach($todos as $todo){
    echo form_input('ordre[]',set_value('ordre',$i));
    echo form_label(' : '.$todo->task, 'task');
    $i+=10;
    ?><br><?php
}
echo form_submit('Ordonner','Ordonner');
echo form_close();
//affichage des erreurs liées aux règles 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

