<!DOCTYPE html>
<html lang="fr">
<head>
        <meta charset="utf-8">
        <title><?php echo $title ?></title>
        
</head>
<body>
        <div class="container">
        <h1>Projet Todo</h1>
        <?php foreach ($todos as $todo): ?><br></br>
            <?php echo $todo->task;  ?>
        <a href = <?php echo base_url('Todo/Modifier/'.$todo->id)?>>Modifier</a>
        <a href=<?php echo base_url('Todo/supprimer/'.$todo->id)?>>supprimer</a>
        <a href= <?php echo base_url('Todo/fait/'.$todo->id) ?>>fait</a>
        <?php endforeach; ?> <br></br> 
        <a href=<?php echo base_url('Todo/add')?>>ajouter</a><br></br>
        <a href=<?php echo base_url('Todo/ordre')?>>Reordonner</a>
</html>

