<title> Modif</title>
<h1>Modifier</h1>
<?php
//affichage des erreurs liées aux règles 
echo validation_errors();
echo form_open(); 
echo form_label('ordre :','ordre');
echo form_input('ordre', set_value('ordre', $update['ordre']));
echo form_label('tache :','task');
echo form_input('task', set_value('task', $update['task']));
echo form_submit('Modifier','Modifier');
echo form_close(); 

