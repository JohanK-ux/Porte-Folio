<?php

class TodoModel extends CI_Model{
    public function __contruct() {
        parent::__construct();
    }
    
   function get_By_Id($id){
        return $this->db->get_where('TableTodo',array('id'=>$id))->row_array();
    }
    
    function get_all(){
        $this->db->order_by('ordre');
        return $this->db->get('TableTodo')->result_object();
    }
    
     function add($params){
        $this->db->insert('TableTodo',$params);
        return $this->db->insert_id();
    }
   function update($id,$params){
        $this->db->where('id',$id);
        $this->db->update('TableTodo',$params);
    }
   function delete($id){
        $this->db->delete('TableTodo',array('id'=>$id));
    }
    function count(){
        
    }
}

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

