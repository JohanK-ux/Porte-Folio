<?php
class Todo extends CI_Controller{

    

    public function __construct(){
        parent::__construct();
        //instanciation du modele pour qu'il devienne disponible dans toutes les methodes
        //du controleur 
        //todoMODEL est la donnée membre de type TodoModel
        $this->load->model('TodoModel');
        $this->load->helper('url','form');
        $this->load->library('form_validation');
        $this->load->helper('url');
    } 
    public function index(){
        //1.Charger les données 
        $all_todos = $this->TodoModel->get_all();
        //2.Préparer les données pour la vue 
        $data = array();
        $data['title']= "au boulot!";
        $data['todos'] = $all_todos;
        //3.Générer la vue 
        $this->load->view('TodoIndex',$data);
    }

    public function fait($id){ 
        $params = array ('completed'=>1);
        $this->TodoModel->update($id,$params);
        
        redirect('Todo/index');
        
    }
    public function add(){ 
        $this->form_validation->set_rules('ordre','ordre','required|numeric');
        $this->form_validation->set_rules('task','tache','required');
        if ($this->form_validation->run()==TRUE){
            $ordre = $this->input->post('ordre');
            $task = $this->input->post('task');
            $params = array('ordre'=>$ordre,'task'=>$task,'completed'=>0);
            $this->TodoModel->add($params);
            redirect(base_url('index.php/Todo/index'));   
        }
             $this->load->view('TodoAdd');
        }
    
    
    public function supprimer ($id){
        $this->TodoModel->delete($id);
        redirect('Todo/index');
    }
    public function modifier($id){
        $this->form_validation->set_rules('ordre','ordre','required|numeric');
        $this->form_validation->set_rules('task','tache','required');
        $data['update']= $this->TodoModel->get_By_Id($id);
        if ($this->form_validation->run()==TRUE){
            $ordre = $this->input->post('ordre');
            $task = $this->input->post('task');
            $params = array('ordre'=>$ordre,'task'=>$task,'completed'=>0);
            $this->TodoModel->update($id,$params);
            redirect(base_url('index.php/Todo/index'));
    }
    $this->load->view('TodoUpdate',$data);
    }
    public function ordre(){
        $data['todos']=$this->TodoModel->get_all();
        foreach($data['todos'] as $todo){
            $this->form_validation->set_rules('ordre[]', 'ordre', 'required|numeric');    
        }
        if ($this->form_validation->run()==TRUE){
            $ordre = $this->input->post('ordre[]');
            $compteur =0;
            foreach ($data['todos'] as $todo){
                $params = array('ordre'=>$ordre[$compteur]);
                $this->TodoModel->update($todo->id, $params); 
                $compteur+=1;                
            }
            redirect(base_url('index.php/Todo/index'));
        }
                $this->load->view('TodoOrdre',$data);

    }
       
            
}
           
        
    







